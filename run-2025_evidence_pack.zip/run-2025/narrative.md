**Narrative**

IRS-ready summary of eligible activities, uncertainties, and experimentation.